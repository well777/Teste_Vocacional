from collections import defaultdict

class Grafo:
    def __init__(self):
        self.grafo = defaultdict(list)

    def adicionar_aresta(self, u, v):
        self.grafo[u].append(v)
        self.grafo[v].append(u)

    def dfs(self, vertice, visitados, componente):
        visitados.add(vertice)
        componente.append(vertice)

        for vizinho in self.grafo[vertice]:
            if vizinho not in visitados:
                self.dfs(vizinho, visitados, componente)

    def encontrar_componentes_conectados(self):
        visitados = set()
        componentes = []

        for vertice in self.grafo:
            if vertice not in visitados:
                componente = []
                self.dfs(vertice, visitados, componente)
                componentes.append(componente)

        return componentes



grafo = Grafo()
grafo.adicionar_aresta(0, 1)
grafo.adicionar_aresta(0, 2)
grafo.adicionar_aresta(1, 2)
grafo.adicionar_aresta(3, 4)

componentes_conectados = grafo.encontrar_componentes_conectados()


print("Componentes Conectados:")
for componente in componentes_conectados:
    print(componente)
