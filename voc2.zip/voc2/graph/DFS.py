def dfs(graph, start_vertex):
    visited = set()  # Conjunto para controlar os vértices visitados
    dfs_util(graph, start_vertex, visited)

def dfs_util(graph, vertex, visited):
    visited.add(vertex)
    print(vertex)  # Faz algo com o vértice atual (exibe seu valor)

    for adjacent_vertex in graph[vertex]:
        if adjacent_vertex not in visited:
            dfs_util(graph, adjacent_vertex, visited)