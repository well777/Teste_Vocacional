class Grafo:
    def __init__(self, num_vertices):
        self.num_vertices = num_vertices
        self.grafo = []

    def adicionar_aresta(self, origem, destino, peso):
        self.grafo.append([origem, destino, peso])

    def imprimir_distancias(self, distancias):
        print("Vertice    Distancia do Vertice de Origem")
        for i in range(self.num_vertices):
            print("{0}\t\t{1}".format(i, distancias[i]))

    def bellman_ford(self, origem):
        distancias = [float("inf")] * self.num_vertices
        distancias[origem] = 0

        for _ in range(self.num_vertices - 1):
            for origem, destino, peso in self.grafo:
                if distancias[origem] != float("inf") and distancias[origem] + peso < distancias[destino]:
                    distancias[destino] = distancias[origem] + peso

        for origem, destino, peso in self.grafo:
            if distancias[origem] != float("inf") and distancias[origem] + peso < distancias[destino]:
                print("O grafo contém um ciclo de peso negativo")
                return

        self.imprimir_distancias(distancias)


# Exemplo de uso
grafo = Grafo(5)
grafo.adicionar_aresta(0, 1, -1)
grafo.adicionar_aresta(0, 2, 4)
grafo.adicionar_aresta(1, 2, 3)
grafo.adicionar_aresta(1, 3, 2)
grafo.adicionar_aresta(1, 4, 2)
grafo.adicionar_aresta(3, 2, 5)
grafo.adicionar_aresta(3, 1, 1)
grafo.adicionar_aresta(4, 3, -3)

origem = 0
grafo.bellman_ford(origem)
