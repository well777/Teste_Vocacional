import math

def floyd_warshall(vertices, arestas):
    INF = math.inf
    distancias = [[INF] * vertices for _ in range(vertices)]

    
    for origem, destino, peso in arestas:
        distancias[origem][destino] = peso

   
    for i in range(vertices):
        distancias[i][i] = 0

 
    for k in range(vertices):
        for i in range(vertices):
            for j in range(vertices):
                distancias[i][j] = min(distancias[i][j], distancias[i][k] + distancias[k][j])

    return distancias


# Exemplo de uso
num_vertices = 4
arestas = [
    (0, 1, 5),
    (0, 3, 10),
    (1, 2, 3),
    (2, 3, 1)
]

distancias = floyd_warshall(num_vertices, arestas)


print("Matriz de distâncias:")
for i in range(num_vertices):
    for j in range(num_vertices):
        if distancias[i][j] == math.inf:
            print("inf", end="\t")
        else:
            print(distancias[i][j], end="\t")
    print()
